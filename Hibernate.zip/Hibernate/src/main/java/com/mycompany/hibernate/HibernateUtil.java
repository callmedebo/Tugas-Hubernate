/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hibernate;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 *
 * @author Debora Marianthi
 */

// Buat kelas konfigurasi Hibernate
public class HibernateUtil {

    private static final SessionFactory sessionFactory;

    static {
        try {
            // Memuat konfigurasi Hibernate dari file hibernate.cfg.xml
            Configuration configuration = new Configuration().configure();

            // Membuat Session Factory
            sessionFactory = configuration.buildSessionFactory();
        } catch (HibernateException ex) {
            // Jika terjadi kesalahan, tampilkan pesan error dan keluar
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }
}
