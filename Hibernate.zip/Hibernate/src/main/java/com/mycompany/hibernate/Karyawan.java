/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hibernate;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.persistence.*;

/**
 *
 * @author Debora Marianthi
 */
@Entity
@Table(name = "karyawan")
public class Karyawan {

    @Id
    @Column(name = "nomor_induk")
    private String nomorInduk;

    @Column(name = "nama")
    private String nama;

    @Column(name = "alamat")
    private String alamat;

    @Column(name = "tanggal_lahir")
    private LocalDate tanggalLahir;

    @Column(name = "tanggal_masuk")
    private LocalDate tanggalMasuk;

    public String getNomorInduk() {
        return nomorInduk;
    }

    public void setNomorInduk(String nomorInduk) {
        this.nomorInduk = nomorInduk;
    }

    /**
     * @return the nama
     */
    public String getNama() {
        return nama;
    }

    /**
     * @param nama the nama to set
     */
    public void setNama(String nama) {
        this.nama = nama;
    }

    /**
     * @return the alamat
     */
    public String getAlamat() {
        return alamat;
    }

    /**
     * @param alamat the alamat to set
     */
    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    /**
     * @return the tanggalLahir
     */
    public String getTanggalLahir() {
        return this.tanggalLahir.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
    }

    /**
     * @param tanggalLahir the tanggalLahir to set
     */
    public void setTanggalLahir(String tanggalLahir) {
        this.tanggalLahir = LocalDate.parse(tanggalLahir, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }

    /**
     * @return the tanggalMasuk
     */
    public String getTanggalMasuk() {
        return this.tanggalMasuk.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
    }

    /**
     * @param tanggalMasuk the tanggalMasuk to set
     */
    public void setTanggalMasuk(String tanggalMasuk) {
        this.tanggalMasuk = LocalDate.parse(tanggalMasuk, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }
}