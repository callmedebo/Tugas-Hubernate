/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hibernate;

/**
 *
 * @author Debora Marianthi
 */
public interface KaryawanDAO {

    void save(Karyawan karyawan);

    Karyawan get(String nomorInduk);

    void update(Karyawan karyawan);

    void delete(Karyawan karyawan);
    
    void findAll(Karyawan karyawan);
}
