/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hibernate;

import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;

/**
 *
 * @author Debora Marianthi
 */
public class KaryawanDAOImpl implements KaryawanDAO {

    @Override
    public void save(Karyawan karyawan) {
        // Mulai transaksi
        try ( // Membuat sesi Hibernate
                Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Mulai transaksi
            session.beginTransaction();
            // Menyimpan objek Karyawan ke database
            session.save(karyawan);
            // Selesai transaksi
            session.getTransaction().commit();
            // Menutup sesi
        } catch (Exception ex) {
            // Menangani exception yang terjadi
            // Misalnya, menampilkan pesan error ke user atau menuliskan log error ke file
            ex.printStackTrace();
        }
    }

    @Override
    public Karyawan get(String nomorInduk) {
        Karyawan karyawan = null;
        // Membaca data Karyawan dari database
        try ( // Membuat sesi Hibernate
                Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Membaca data Karyawan dari database
            karyawan = (Karyawan) session.get(Karyawan.class, nomorInduk);
            // Menutup sesi
        } catch (Exception ex) {
            // Menangani exception yang terjadi
            // Misalnya, menampilkan pesan error ke user atau menuliskan log error ke file
            ex.printStackTrace();
        }
        return karyawan;
    }

    @Override
    public void update(Karyawan karyawan) {
        // Mulai transaksi
        try ( // Membuat sesi Hibernate
                Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Mulai transaksi
            session.beginTransaction();
            // Menyimpan perubahan ke database
            session.update(karyawan);
            // Selesai transaksi
            session.getTransaction().commit();
            // Menutup sesi
        } catch (Exception ex) {
            // Menangani exception yang terjadi
            // Misalnya, menampilkan pesan error ke user atau menuliskan log error ke file
            ex.printStackTrace();
        }
    }

    @Override
    public void delete(Karyawan karyawan) {
        // Mulai transaksi
        try ( // Membuat sesi Hibernate
                Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Mulai transaksi
            session.beginTransaction();
            // Menghapus data dari database
            session.delete(karyawan);
            // Selesai transaksi
            session.getTransaction().commit();
            // Menutup sesi
        } catch (Exception ex) {
            // Menangani exception yang terjadi
            // Misalnya, menampilkan pesan error ke user atau menuliskan log error ke file
            ex.printStackTrace();
        }
    }

    @Override
    public void findAll(Karyawan karyawan) {
        try (
            // Buka sesi Hibernate
            Session session = HibernateUtil.getSessionFactory().openSession()) {

            // Mulai transaksi
            session.beginTransaction();

            // Buat query Criteria untuk entitas Karyawan
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Karyawan> criteria = builder.createQuery(Karyawan.class);
            Root<Karyawan> root = criteria.from(Karyawan.class);
            criteria.select(root);

            // Eksekusi query dan ambil hasilnya
            List<Karyawan> karyawans = session.createQuery(criteria).getResultList();

            // Commit transaksi
            session.getTransaction().commit();

            // Tutup sesi
            session.close();

            // Tampilkan semua data karyawan
            for (Karyawan k : karyawans) {
                System.out.println(k.getNomorInduk() + " " + k.getNama()
                        + " " + k.getAlamat() + " " + k.getTanggalLahir()
                        + " " + k.getTanggalMasuk()
                );
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
