/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.hibernate;

import java.util.Scanner;

/**
 *
 * @author Debora Marianthi
 */
public class Menu {

    public static void main(String[] args) {
        int menu;
        Scanner input = new Scanner(System.in);
        KaryawanDAO karyawanDAO = new KaryawanDAOImpl();
        Karyawan kr = new Karyawan();

        // Lakukan perulangan selama pengguna tidak memilih pilihan keluar
        while (true) {
            // Tampilkan menu pilihan
            System.out.println("Menu:");
            System.out.println("1. Tambah data");
            System.out.println("2. Lihat data");
            System.out.println("3. Edit data");
            System.out.println("4. Hapus data");
            System.out.println("5. Lihat semua data");
            System.out.println("6. Keluar");
            System.out.println("Masukkan pilihan Anda: ");
            menu = input.nextInt();

            // Kelola pilihan menu
            switch (menu) {
                case 1:
                    // Tambah data
                    System.out.println("Anda memilih menu Tambah Data");
                    Scanner data1 = new Scanner(System.in);
                    System.out.println("Masukkan Nomor Induk Karyawan : ");
                    String nomorInduk = data1.nextLine();
                    Scanner data2 = new Scanner(System.in);
                    System.out.println("Masukkan Nama Karyawan : ");
                    String nama = data2.nextLine();
                    Scanner data3 = new Scanner(System.in);
                    System.out.println("Masukkan Alamat : ");
                    String alamat = data3.nextLine();
                    Scanner data4 = new Scanner(System.in);
                    System.out.println("Masukkan Tanggal Lahir : ");
                    String TglLahir = data4.nextLine();
                    Scanner data5 = new Scanner(System.in);
                    System.out.println("Masukkan Tanggal Masuk : ");
                    String TglMasuk = data4.nextLine();
                    kr.setNomorInduk(nomorInduk);
                    kr.setNama(nama);
                    kr.setAlamat(alamat);
                    kr.setTanggalLahir(TglLahir);
                    kr.setTanggalMasuk(TglMasuk);
                    // Menyimpan objek Karyawan ke database
                    karyawanDAO.save(kr);
                    break;
                case 2:
                    // Lihat data
                    System.out.println("Anda memilih menu Lihat Data");
                    // membuat objek Scanner
                    Scanner dataId = new Scanner(System.in);
                    System.out.println("Masukkan Nomor Induk Karyawan : ");
                    // membaca string dari input
                    String Id = dataId.nextLine();
                    kr = karyawanDAO.get(Id);
                    System.out.println("Nomor Induk : " + kr.getNomorInduk());
                    System.out.println("Nama        : " + kr.getNama());
                    System.out.println("Alamat      : " + kr.getAlamat());
                    System.out.println("Tanggal Lahir : " + kr.getTanggalLahir());
                    System.out.println("Tanggal Masuk : " + kr.getTanggalMasuk());
                    break;
                case 3:
                    // Edit data
                    System.out.println("Anda memilih menu Edit Data");
                    // membuat objek Scanner
                    Scanner dataEdit1 = new Scanner(System.in);
                    System.out.println("Masukkan Nomor Induk Karyawan : ");
                    // membaca string dari input
                    String data = dataEdit1.nextLine();
                    kr = karyawanDAO.get(data);
                    Scanner dataEdit2 = new Scanner(System.in);
                    System.out.println("Masukkan Alamat Baru : ");
                    String dataAlamat = dataEdit2.nextLine();
                    kr.setAlamat(dataAlamat);
                    karyawanDAO.update(kr);
                    break;
                case 4:
                    // Hapus data
                    System.out.println("Anda memilih menu Hapus Data");
                    // membuat objek Scanner
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Masukkan Nomor Induk Karyawan : ");
                    // membaca string dari input
                    String dataHapus = sc.nextLine();
                    kr = karyawanDAO.get(dataHapus);
                    karyawanDAO.delete(kr);
                    break;
                case 5:
                    System.out.println("Anda memilih menu Lihat Semua Data");
                    karyawanDAO.findAll(null);
                    break;
                case 6:
                    // Keluar
                    System.out.println("Anda memilih menu Keluar");
                    return; // Keluar dari program
                default:
                    System.out.println("Pilihan tidak valid");
            }
        }
    }
}
