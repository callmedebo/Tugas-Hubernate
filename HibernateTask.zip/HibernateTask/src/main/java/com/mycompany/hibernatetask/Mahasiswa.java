/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hibernatetask;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.persistence.*;

/**
 *
 * @author Debora Marianthi
 */
@Entity
@Table(name = "mahasiswa")
public class Mahasiswa implements Serializable{

    @Id
    @Column(name = "nim")
    private String nim;

    @Column(name = "nama")
    private String nama;

    @Column(name = "jenis_kelamin")
    private String JenisKelamin;

    @Column(name = "tanggal_lahir")
    private LocalDate Tanggallahir;

    @Column(name = "alamat")
    private String Alamat;

    public String getnim() {
        return nim;
    }

    public void setnim(String nim) {
        this.nim = nim;
    }

    /**
     * @return the nama
     */
    public String getnama() {
        return nama;
    }

    /**
     * @param nama the nama to set
     */
    public void setnama(String nama) {
        this.nama = nama;
    }

    /**
     * @return the JenisKelamin
     */
    public String getJenisKelamin() {
        return JenisKelamin;
    }

    /**
     * @param JenisKelamin the jeniskelamin to set
     */
    public void setJenisKelamin(String JenisKelamin) {
        this.JenisKelamin = JenisKelamin;
    }

    /**
     * @return the tanggalLahir
     */
    public String getTanggallahir() {
        return this.Tanggallahir.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
    }

    /**
     * @param tanggalLahir the tanggalLahir to set
     */
    public void setTanggallahir(String tanggalLahir) {
        this.Tanggallahir = LocalDate.parse(tanggalLahir, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
    }

    /**
     * @return the Alamat
     */
    public String getAlamat() {
        return Alamat;
    }

    /**
     * @param Alamat the Alamat to set
     */
    public void setAlamat(String Alamat) {
        this.Alamat = Alamat;
    }
}

