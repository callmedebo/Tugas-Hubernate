/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.hibernatetask;

/**
 *
 * @author Debora Marianthi
 */
public interface MahasiswaCRUD {
    
    void save(Mahasiswa mahasiswa);

    Mahasiswa get(String NIM);

    void update(Mahasiswa mahasiswa);

    void delete(Mahasiswa mahasiswa);

    void findAll(Mahasiswa mahasiswa);
}
