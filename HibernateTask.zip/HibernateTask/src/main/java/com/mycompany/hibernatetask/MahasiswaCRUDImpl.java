/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hibernatetask;

import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.hibernate.Session;

/**
 *
 * @author Debora Marianthi
 */
public class MahasiswaCRUDImpl implements MahasiswaCRUD {
   
    @Override
    public void save(Mahasiswa mahasiswa) {
        // Mulai transaksi
        try ( // Membuat sesi Hibernate
                 Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Mulai transaksi
            session.beginTransaction();
            // Menyimpan objek Mahasiswa ke database
            session.save(mahasiswa);
            // Selesai transaksi
            session.getTransaction().commit();
            // Menutup sesi
        } catch (Exception ex) {
            // Menangani exception yang terjadi
            // Misalnya, menampilkan pesan error ke user atau menuliskan log error ke file
            ex.printStackTrace();
        }
    }

    @Override
    public Mahasiswa get(String NIM) {
        Mahasiswa mahasiswa = null;
        // Membaca data Mahasiswa dari database
        try ( // Membuat sesi Hibernate
                 Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Membaca data Mahasiswa dari database
            mahasiswa = (Mahasiswa) session.get(Mahasiswa.class, NIM);
            // Menutup sesi
        } catch (Exception ex) {
            // Menangani exception yang terjadi
            // Misalnya, menampilkan pesan error ke user atau menuliskan log error ke file
            ex.printStackTrace();
        }
        return mahasiswa;
    }

    @Override
    public void update(Mahasiswa mahasiswa) {
        // Mulai transaksi
        try ( // Membuat sesi Hibernate
                 Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Mulai transaksi
            session.beginTransaction();
            // Menyimpan perubahan ke database
            session.update(mahasiswa);
            // Selesai transaksi
            session.getTransaction().commit();
            // Menutup sesi
        } catch (Exception ex) {
            // Menangani exception yang terjadi
            // Misalnya, menampilkan pesan error ke user atau menuliskan log error ke file
            ex.printStackTrace();
        }
    }

    @Override
    public void delete(Mahasiswa mahasiswa) {
        // Mulai transaksi
        try ( // Membuat sesi Hibernate
                 Session session = HibernateUtil.getSessionFactory().openSession()) {
            // Mulai transaksi
            session.beginTransaction();
            // Menghapus data dari database
            session.delete(mahasiswa);
            // Selesai transaksi
            session.getTransaction().commit();
            // Menutup sesi
        } catch (Exception ex) {
            // Menangani exception yang terjadi
            // Misalnya, menampilkan pesan error ke user atau menuliskan log error ke file
            ex.printStackTrace();
        }
    }

    @Override
    public void findAll(Mahasiswa mahasiswa) {
        try (
                // Buka sesi Hibernate
                 Session session = HibernateUtil.getSessionFactory().openSession()) {

            // Mulai transaksi
            session.beginTransaction();

            // Buat query Criteria untuk entitas Mahasiswa
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Mahasiswa> criteria = builder.createQuery(Mahasiswa.class);
            Root<Mahasiswa> root = criteria.from(Mahasiswa.class);
            criteria.select(root);

            // Eksekusi query dan ambil hasilnya
            List<Mahasiswa> mahasiswas = session.createQuery(criteria).getResultList();

            // Commit transaksi
            session.getTransaction().commit();

            // Tutup sesi
            session.close();

            // Tampilkan semua data mahasiswa
           for (Mahasiswa mhs : mahasiswas) {
                System.out.println(mhs.getnim() + " " + mhs.getnama()
                        + " " + mhs.getJenisKelamin() + " " + mhs.getTanggallahir()
                        + " " + mhs.getAlamat()
                );
            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
