/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hibernatetask;

import java.util.Scanner;

/**
 *
 * @author Debora Marianthi
 */
public class Menu {
    
    public static void main(String[] args) {
        int menu;
        Scanner input = new Scanner(System.in);
        MahasiswaCRUD mahasiswaCRUD = new MahasiswaCRUDImpl();
        Mahasiswa mhs = new Mahasiswa();

        // Lakukan perulangan selama pengguna tidak memilih pilihan keluar
        while (true) {
            // Tampilkan menu pilihan
            System.out.println("Menu:");
            System.out.println("1. Tambah data");
            System.out.println("2. Lihat data");
            System.out.println("3. Edit data");
            System.out.println("4. Hapus data");
            System.out.println("5. Lihat semua data");
            System.out.println("6. Keluar");
            System.out.println("Masukkan pilihan Anda: ");
            menu = input.nextInt();

            // Kelola pilihan menu
            switch (menu) {
                case 1:
                    // Tambah data
                    System.out.println("Anda memilih menu Tambah Data");
                    Scanner data1 = new Scanner(System.in);
                    System.out.println("Masukkan NIM Mahasiswa : ");
                    String nim = data1.nextLine();
                    Scanner data2 = new Scanner(System.in);
                    System.out.println("Masukkan Nama Mahasiswa : ");
                    String nama = data2.nextLine();
                    Scanner data3 = new Scanner(System.in);
                    System.out.println("Masukkan Jenis Kelamin Mahasiswa : ");
                    String JenisKelamin = data3.nextLine();
                    Scanner data4 = new Scanner(System.in);
                    System.out.println("Masukkan Tanggal Lahir : ");
                    String TglLahir = data4.nextLine();
                    Scanner data5 = new Scanner(System.in);
                    System.out.println("Masukkan Alamat : ");
                    String Alamat = data4.nextLine();
                    mhs.setnim(nim);
                    mhs.setnama(nama);
                    mhs.setJenisKelamin(JenisKelamin);
                    mhs.setTanggallahir(TglLahir);
                    mhs.setAlamat(Alamat);
                    // Menyimpan objek Mahasiswa ke database
                    mahasiswaCRUD.save(mhs);
                    break;
                case 2:
                    // Lihat data
                    System.out.println("Anda memilih menu Lihat Data");
                    // membuat objek Scanner
                    Scanner dataId = new Scanner(System.in);
                    System.out.println("Masukkan NIM Mahasiswa : ");
                    // membaca string dari input
                    String Id = dataId.nextLine();
                    mhs = mahasiswaCRUD.get(Id);
                    System.out.println("NIM : " + mhs.getnim());
                    System.out.println("Nama        : " + mhs.getnama());
                    System.out.println("Jenis Kelamin      : " + mhs.getJenisKelamin());
                    System.out.println("Tanggal Lahir : " + mhs.getTanggallahir());
                    System.out.println("Alamat      : " + mhs.getAlamat());
                    break;
                case 3:
                    // Edit data
                    System.out.println("Anda memilih menu Edit Data");
                    // membuat objek Scanner
                    Scanner dataEdit1 = new Scanner(System.in);
                    System.out.println("Masukkan NIM Mahasiswa : ");
                    // membaca string dari input
                    String data = dataEdit1.nextLine();
                    mhs = mahasiswaCRUD.get(data);
                    Scanner dataEdit2 = new Scanner(System.in);
                    System.out.println("Masukkan Alamat Baru : ");
                    String dataAlamat = dataEdit2.nextLine();
                    mhs.setAlamat(dataAlamat);
                    mahasiswaCRUD.update(mhs);
                    break;
                case 4:
                    // Hapus data
                    System.out.println("Anda memilih menu Hapus Data");
                    // membuat objek Scanner
                    Scanner sc = new Scanner(System.in);
                    System.out.println("Masukkan NIM Mahasiswa : ");
                    // membaca string dari input
                    String dataHapus = sc.nextLine();
                    mhs = mahasiswaCRUD.get(dataHapus);
                    mahasiswaCRUD.delete(mhs);
                    break;
                case 5:
                    System.out.println("Anda memilih menu Lihat Semua Data");
                    mahasiswaCRUD.findAll(null);
                    break;
                case 6:
                    // Keluar
                    System.out.println("Anda memilih menu Keluar");
                    return; // Keluar dari program
                default:
                    System.out.println("Pilihan tidak valid");
            }
        }
    }
}
